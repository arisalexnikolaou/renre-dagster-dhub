# About

Data pipeline to maintain Data Hub.

## Getting started

1. Create an .env file based on the values of .env_example file.
2. Clone and run the Data Lake Dev Solution's services: https://gitlab.prd.mercuria.systems/development/data/data-lake-dev
3. Run setup.ps1 from command line. You may have to run this from an Admin console if you can't run remote signed scripts.
4. Debug the solution using the 'run dagit' option from vs.code debug launcher

## Developing

You can run the following command to validate your build before checking in a commit.

```
pre-commit run --all-files
```

## Build Quality Status

TBP

## Docker builds

To build the docker image run the following command from a bash command terminal

```
docker build . -t temp --build-arg PYTHON_VERSION=latest_mssql_3.11 --build-arg SCHEMA_READER_PWD=to_be_provided --build-arg SCHEMA_READER_UID=to_be_provided
```

## Related JIRA issues

https://mercuria.atlassian.net/browse/DA-89
https://mercuria.atlassian.net/browse/DA-158

TODO: add support for Azure AD as well as Tableue


dagster dev -w workspace.yaml
