import pytest


@pytest.mark.unit
def test_1():
    assert 1 == 1
