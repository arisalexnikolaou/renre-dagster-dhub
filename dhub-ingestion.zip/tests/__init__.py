from dotenv import load_dotenv
import os

if os.path.exists(".env"):
    load_dotenv()  # take environment variables from .env when debugging
