from dagster._cli import main
import os
from dotenv import load_dotenv

os.environ["DAGSTER_HOME"] = os.path.join(os.getcwd(), "data")

if os.path.exists(".env"):
    load_dotenv()  # take environment variables from .env when debugging

main()
