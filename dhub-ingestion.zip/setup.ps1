python -m venv .venv
.venv/scripts/activate.ps1
pip install poetry
poetry install
pre-commit install
