import pyodbc

print("Started")

SERVER = "DB_SRSREP_DEV.mercuria.met,1433"
DATABASE = "srs-dwh_DEV"

connectionString = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={SERVER};DATABASE={DATABASE};trust_server_certificate=yes;encrypt=no;Trusted_Connection=yes"

conn = pyodbc.connect(connectionString)

cursor = conn.cursor()
result = cursor.execute("Select * From SysObjects")

rows = [dict(zip([column[0] for column in cursor.description], row)) for row in cursor.fetchall()]
print(rows)

print("Finished")
