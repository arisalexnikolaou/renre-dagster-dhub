import gitlab
import os
from logging import Logger


def write_text_to_file(file_path: str, text: str) -> None:
    with open(file_path, "w") as file:
        file.write(text)


def get_file(file_path: str, logger: Logger) -> None:
    project_path = os.getenv("DHUB_GITLAB_PROJECT_URL", "https://gitlab.prd.mercuria.systems/")

    logger.debug(f"Updating file {file_path} from GitLab url {project_path}.")

    token = os.getenv("DHUB_GITLAB_PROJECT_TOKEN", "")
    project_id = os.getenv("DHUB_GITLAB_PROJECT_ID", 1259)

    gl = gitlab.Gitlab(url=project_path, private_token=token)
    project = gl.projects.get(project_id)

    raw_content = project.files.raw(file_path=file_path, ref="main")
    text = raw_content.decode("utf-8")  # type: ignore

    if os.path.exists(file_path):
        os.remove(file_path)

    write_text_to_file(file_path, text)

    logger.debug(f"File {file_path} updated from GitLab url {project_path}.")
