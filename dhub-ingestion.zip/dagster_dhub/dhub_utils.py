import contextlib
import os
from typing import Any, Optional
from dagster_dhub.resources import DataHubApiCredentials
from datahub.ingestion.run.pipeline import Pipeline
from yaml import safe_load, YAMLError
import pandas as pd
from dagster import AssetObservation, OpExecutionContext
import json


def process_to_dhub(context: OpExecutionContext, pipeline_config: Any, datahub_api: DataHubApiCredentials, env: Optional[str | None] = None) -> pd.DataFrame:
    """Submits meta data to a configurable DataHub endpoint.

    Args:
        context (OpExecutionContext): The context to log to.,
        pipeline_config (Any): The pipeline config.
        datahub_api (DataHubApiCredentials): The endpoint to connect to.
        env (Optional[str]): The platform environment. This should either be DEV or PROD

    Returns:
        pd: Returns the report from the data hub sink component.
    """

    main_config = pipeline_config["source"]["config"]
    if env:
        main_config["platform_instance"] = env

    # pull token from environmental variable rather than configurable resource to protect secret
    token = os.getenv("DATAHUB_GMS_ACCESS_TOKEN", "")

    pipeline_config["datahub_api"]["server"] = datahub_api.server
    if token:
        pipeline_config["datahub_api"]["token"] = token

    pipeline_config["sink"]["config"]["server"] = datahub_api.server
    if token:
        pipeline_config["sink"]["config"]["token"] = token

    running_pipeline = Pipeline.create(pipeline_config)

    running_pipeline.run()

    source_report = running_pipeline.source.get_report()

    context.log_event(AssetObservation(asset_key="source_report", metadata=source_report.as_obj()))  # type: ignore

    sink_report = running_pipeline.sink.get_report().as_obj()

    df = pd.DataFrame(sink_report)

    context.log_event(AssetObservation(asset_key="sink_report", metadata=sink_report))  # type: ignore

    if source_report.failures:  # type: ignore
        total_errors: int = 0
        # report job failures
        with contextlib.suppress(Exception):
            jobs = json.loads(source_report.as_json())["failures"]["jobs"]
            for job in jobs:
                # ignore this error that ... a bit of a hack as this will only occur for sql server ingestion jobs
                if "Invalid object name" not in str(job):
                    context.log.error(job)
                    total_errors += 1

        if total_errors > 0:
            raise UserWarning("Failed to process schema to Data Hub due to one or more failures. Please see the log for more details.")
    else:
        pipeline_name = pipeline_config["pipeline_name"]
        context.log.info(f"Data Hub ingestion of pipeline {pipeline_name} completed. Please see the event log for more details.")

    return df


def get_config(dir: str, file_name: str) -> Any:
    """Parses a yaml based configuration file.

    Args:
        dir (str): The directory of the file.
        file_name (str): The yaml file to ingest.

    Raises:
        UserWarning: Raised if there is a yaml parsing error.

    Returns:
        Any: A dictionary of the content.
    """
    file_name = os.path.join(dir, file_name)

    config: Any

    with open(file_name, "r") as stream:
        try:
            config = safe_load(stream)

        except YAMLError as e:
            raise UserWarning(f"Failed to parse YAML spec file at {file_name}.") from e

    return config
