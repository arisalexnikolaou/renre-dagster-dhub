from dagster_dhub.assets import sql_to_dhub_group, s3_to_dhub_group, csv_to_dhub_group, glossary_to_dhub_group
from dagster_dhub.resources import DataHubApiCredentials
from dagster import EnvVar

import os
from dagster import (
    AssetSelection,
    Definitions,
    ScheduleDefinition,
    define_asset_job,
)

all_asset_groups = [*sql_to_dhub_group, *s3_to_dhub_group, *csv_to_dhub_group, *glossary_to_dhub_group]

dhub_jobs = define_asset_job("dhub_jobs", selection=AssetSelection.all())

# Addition: a ScheduleDefinition the job it should run and a cron schedule of how frequently to run it
dhub_job_schedules = ScheduleDefinition(
    job=dhub_jobs,
    cron_schedule=os.getenv("DATAHUB_INGESTION_SCHEDULE", "5 8 * * 0"),  # every sunday
)

defs = Definitions(
    assets=all_asset_groups,
    resources={
        "datahub_api": DataHubApiCredentials(server=os.getenv("DATAHUB_GMS_URL", "")),
        "gitlab_project_id": EnvVar("DHUB_GITLAB_PROJECT_ID"),
        "gitlab_project_url": EnvVar("DHUB_GITLAB_PROJECT_URL"),
    },
    jobs=[dhub_jobs],
    sensors=[],
    schedules=[dhub_job_schedules],
)
