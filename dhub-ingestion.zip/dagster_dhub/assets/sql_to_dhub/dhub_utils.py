from typing import Any
from dagster_dhub.resources import DataHubApiCredentials, DbConnect
from dagster_dhub.dhub_utils import process_to_dhub, get_config
from dagster import OpExecutionContext
import os
import pandas as pd


def ingest_schema_to_dhub(context: OpExecutionContext, db: DbConnect, datahub_api: DataHubApiCredentials) -> pd.DataFrame:
    """Ingest sql schemas into a configurable data hub server.

    All database connections will rely on a trusted ODBC connection.

    Args:
        logger: The logger to log pipeline output.
        db (DbConnect): The database configuration settings to connect to.
        datahub_api (DataHubApiCredentials): Configuration details to connect to the data hub instance to post meta data to.

    Returns:
        bool: true of the pipeline succeeded.
    """
    context.log.info(f"Ingesting sql schema from {db.database} to Data Hub.")

    pipeline_config: Any = get_config(os.path.dirname(__file__), "spec.yml")
    pipeline_config["pipeline_name"] = f"sql_{db.database}_{db.host_port}".replace(",", "_").replace("\\", "_").replace("/", "_").replace(".", "_").lower()

    config = pipeline_config["source"]["config"]

    config["database"] = db.database
    config["host_port"] = db.host_port

    result = process_to_dhub(context, pipeline_config, datahub_api, db.env)

    context.log.info(f"Sql schema from {db.database} to Data Hub ingestion complete.")

    return result
