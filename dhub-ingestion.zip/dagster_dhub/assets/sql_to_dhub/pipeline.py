import os
from dagster_dhub.assets.sql_to_dhub.dhub_utils import ingest_schema_to_dhub
from dagster import OpExecutionContext, MetadataValue, asset
from dagster_dhub.resources import DbConnect, DataHubApiCredentials
import csv
from dagster_dhub.gitlab_utils import get_file
from typing import List


local_dir = os.getcwd()

metadata_val = {"owner": "support@mercuria.com", "docs": MetadataValue.url("https://mercuria.atlassian.net/l/cp/8Zk6tsVm")}


# risk orch
@asset(description="Ingest schemas of sql databases defined in the config/sql_servers.csv file to data datahub.", metadata=metadata_val)
def sql_server_to_datahub(context: OpExecutionContext, datahub_api: DataHubApiCredentials) -> None:
    file_path = "config/sql_servers.csv"

    # update file from gitlab for each run
    get_file(file_path, context.log)

    if os.path.exists(file_path) is False:
        raise UserWarning(f"Configuration file not found: {file_path}.")

    row_number: int = 0
    errors: List[Exception] = []

    with open(file_path, "r") as file:
        reader = csv.reader(file, delimiter="|")

        for row in reader:
            row_number += 1

            if len(row) < 3:
                raise UserWarning(f"Invalid configuration in row {row_number}. Expected database, host and environment values seperated by a pipe.")

            db = DbConnect(database=row[0], host_port=row[1].replace("/", "\\"), env=str(row[2]).upper())

            try:
                ingest_schema_to_dhub(context, db, datahub_api)
            except UserWarning as ex:
                context.log.error(f"Job failure ingesting database '{db.database}' schema on host '{db.host_port}'. See the source report in the log for more details.")
                errors.append(ex)
            except Exception as e:
                context.log.error(f"Failed to ingest database '{db.database}'schema on host '{db.host_port}'.")
                context.log.error(e.args[0])
                errors.append(e)

    if errors:
        raise UserWarning("Failed to process one or more databases. Please see the log for more details.")
