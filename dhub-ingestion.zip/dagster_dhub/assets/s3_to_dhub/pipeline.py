from dagster_dhub.assets.s3_to_dhub.s3_utils import ingest_dl_to_dhub
from dagster import OpExecutionContext, MetadataValue, asset
from dagster_dhub.resources import DataHubApiCredentials
from mercuria_dagster_utils.dl_path import DataLakePathProvider
import pandas as pd

metadata_val = {"owner": "support@mercuria.com", "docs": MetadataValue.url("https://mercuria.atlassian.net/l/cp/8Zk6tsVm")}
dl = DataLakePathProvider()


# source
@asset(description="Ingest schema and meta data from data lake source", metadata=metadata_val)
def dl_source_schema_to_datahub(context: OpExecutionContext, datahub_api: DataHubApiCredentials) -> pd.DataFrame:
    return ingest_dl_to_dhub(context, dl.source, datahub_api)


# standardized
@asset(description="Ingest schema and meta data from data lake standardized", metadata=metadata_val)
def dl_standardized_schema_to_datahub(context: OpExecutionContext, datahub_api: DataHubApiCredentials) -> pd.DataFrame:
    return ingest_dl_to_dhub(context, dl.standardized, datahub_api)


# trusted
@asset(description="Ingest schema and meta data from data lake trusted", metadata=metadata_val)
def dl_trusted_schema_to_datahub(context: OpExecutionContext, datahub_api: DataHubApiCredentials) -> pd.DataFrame:
    return ingest_dl_to_dhub(context, dl.trusted, datahub_api)
