import os
from dagster_dhub.resources import DataHubApiCredentials
from dagster import OpExecutionContext
from dagster_dhub.dhub_utils import process_to_dhub, get_config
import pandas as pd


def ingest_dl_to_dhub(context: OpExecutionContext, path: str, datahub_api: DataHubApiCredentials) -> pd.DataFrame:
    running_pipeline_config = get_config(os.path.dirname(__file__), "spec.yml")

    main_config = running_pipeline_config["source"]["config"]

    include_paths = [{"include": f"s3://{path}/{{table}}/*.*"}, {"include": f"s3://{path}/{{table}}/*/*.*"}]
    main_config["path_specs"] = include_paths

    main_config["add_partition_columns_to_schema"] = True
    main_config["use_s3_bucket_tags"] = True
    main_config["use_s3_object_tags"] = True
    main_config["verify_ssl"] = False

    config = running_pipeline_config["source"]["config"]["aws_config"]

    config["aws_access_key_id"] = os.getenv("AWS_ACCESS_KEY_ID")
    config["aws_secret_access_key"] = os.getenv("AWS_SECRET_ACCESS_KEY")
    config["aws_endpoint_url"] = os.getenv("S3_ENDPOINT_URL")

    # infer environment
    path_lower = path.lower()

    running_pipeline_config["pipeline_name"] = f"s3_{path}".replace(",", "_").replace("\\", "_").replace("/", "_").replace(".", "_").lower()

    env: str = ""
    if "-prd-" in path_lower:
        env = "PRD"
    elif "-dev-" in path_lower:
        env = "DEV"
    elif "-uat-" in path_lower:
        env = "UAT"

    return process_to_dhub(context, running_pipeline_config, datahub_api, env)
