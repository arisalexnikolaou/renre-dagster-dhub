from dagster import load_assets_from_package_module

from . import sql_to_dhub
from . import s3_to_dhub
from . import csv_to_dhub
from . import glossary_to_dhub

sql_to_dhub_group = load_assets_from_package_module(package_module=sql_to_dhub, group_name="sql_to_dhub")
s3_to_dhub_group = load_assets_from_package_module(package_module=s3_to_dhub, group_name="s3_to_dhub")
csv_to_dhub_group = load_assets_from_package_module(package_module=csv_to_dhub, group_name="csv_to_dhub")
glossary_to_dhub_group = load_assets_from_package_module(package_module=glossary_to_dhub, group_name="glossary_to_dhub")
