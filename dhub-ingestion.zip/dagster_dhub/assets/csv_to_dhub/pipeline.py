import os
from dagster import OpExecutionContext, MetadataValue, asset
from dagster_dhub.resources import DataHubApiCredentials
from dagster_dhub.dhub_utils import process_to_dhub, get_config
import pandas as pd
from dagster_dhub.gitlab_utils import get_file

metadata_val = {"owner": "support@mercuria.com", "docs": MetadataValue.url("https://mercuria.atlassian.net/l/cp/8Zk6tsVm")}


@asset(description="Ingest schema and meta data from csv source", metadata=metadata_val)
def csv_source_schema_to_datahub(context: OpExecutionContext, datahub_api: DataHubApiCredentials) -> pd.DataFrame:
    get_file("config/dhub.csv", context.log)

    return process_to_dhub(context, get_config(os.path.dirname(__file__), "spec.yml"), datahub_api)
