import os
from dagster import OpExecutionContext, MetadataValue, asset
from dagster_dhub.resources import DataHubApiCredentials
from dagster_dhub.dhub_utils import process_to_dhub, get_config
import pandas as pd
from dagster_dhub.gitlab_utils import get_file

metadata_val = {"owner": "support@mercuria.com", "docs": MetadataValue.url("https://mercuria.atlassian.net/l/cp/8Zk6tsVm")}


# source
@asset(description="Ingest schema and meta data from a business glossary.", metadata=metadata_val)
def business_glossary_to_datahub(context: OpExecutionContext, datahub_api: DataHubApiCredentials) -> pd.DataFrame:
    get_file("config/business_glossary.yml", context.log)

    return process_to_dhub(context, get_config(os.path.dirname(__file__), "spec.yml"), datahub_api)
