import os
from dagster import MetadataValue, build_op_context
from dagster_dhub.assets.sql_to_dhub.pipeline import sql_server_to_datahub
from dagster_dhub.resources import DataHubApiCredentials
from dotenv import load_dotenv
import logging

if os.path.exists(".env"):
    load_dotenv()  # take environment variables from .env when debugging

local_dir = os.getcwd()

metadata_val = {"owner": "support@mercuria.com", "docs": MetadataValue.url("https://mercuria.atlassian.net/l/cp/8Zk6tsVm")}

datahub_api = DataHubApiCredentials(server=os.getenv("DATAHUB_GMS_URL", ""))
context = build_op_context()

sql_server_to_datahub(context, datahub_api)

logging.debug("Test")
