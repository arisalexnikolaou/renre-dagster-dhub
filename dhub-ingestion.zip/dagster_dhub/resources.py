from dagster import ConfigurableResource
import os
from typing import List


class DataHubApiCredentials(ConfigurableResource["DataHubApiCredentials"]):
    """Api credentials to connect to Data Hub."""

    server: str


class DbConnect(ConfigurableResource["DbConnect"]):
    """Configuration details to connect to an sql database."""

    database: str
    host_port: str
    env: str = "DEV"


def create_db_connect_resource(env_name: str) -> DbConnect:
    vals: List[str] = os.getenv(env_name, "").split("|")
    if len(vals) < 3:
        raise UserWarning(f"Invalid configuration in {env_name}. Expected database, host and environment values seperated by a pipe.")
    return DbConnect(database=vals[0], host_port=vals[1].replace("/", "\\"), env=str(vals[2]).upper())
